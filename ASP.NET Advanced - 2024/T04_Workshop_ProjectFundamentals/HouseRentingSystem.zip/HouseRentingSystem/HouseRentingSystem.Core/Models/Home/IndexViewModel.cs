﻿namespace HouseRentingSystem.Core.Models.Home
{
    public class IndexViewModel
    {
    }
}
