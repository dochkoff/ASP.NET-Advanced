﻿namespace HouseRentingSystem.Core.Contracts
{
    public interface IHouseModel
    {
        public string Title { get; set; }

        public string Address { get; set; }
    }
}
