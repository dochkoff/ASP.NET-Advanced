﻿namespace HouseRentingSystem.Core.Enumerations
{
    public enum HouseSorting
    {
        Newest = 0,
        Price = 1,
        NotRentedFirst = 2
    }
}
